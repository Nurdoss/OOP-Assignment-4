public class List {
    public static void getList() {
        System.out.println("0 - Show full table");
        System.out.println("1 - Show sorted out ID's");
        System.out.println("2 - Show sorted out Clothes And Misc section");
        System.out.println("3 - Show sorted out Color section");
        System.out.println("4 - Show sorted out Size section");
        System.out.println("5 - Show sorted out Type Of Clothes section");
        // System.out.println("6 - Your specific request");
    }
}