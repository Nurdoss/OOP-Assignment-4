package console;public class sql {
}
